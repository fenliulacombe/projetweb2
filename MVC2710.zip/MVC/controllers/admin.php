<?php
class Admin extends Controller{
    protected function index(){
        
    }

    protected function add(){
      
    }

    protected function delete(){
    
    }

    protected function update(){

    }
}