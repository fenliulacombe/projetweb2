<?php
//define DB Params
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","");
define("DB_NAME","projetweb2");

//define URL
define("ROOT_PATH","/");
define("ROOT_URL","http://127.0.0.1/projetweb2/MVC/")

?>