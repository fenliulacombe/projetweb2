    <footer>
       
   	  <div class="row cont-footer">
            
            <div class="col-xs-12 col-md-3 col-lg-3">
            	  <p class="titre-footer">COMPAGNIE</p>
                  <li class="li-f"><a href="#">À propos</a></li>
                  <li class="li-f"><a href="#">Voir les pigistes</a></li>
                  <li class="li-f"><a href="#">Voir les contrats</a></li>
                  <li class="li-f"><a href="/echange/view/contact/contact.php">Nous joindre</a></li>
            </div>
             
            <div class="col-xs-12 col-md-3 col-lg-3">
            	  <p class="titre-footer">MEMBRE</p>
                  <li class="li-f"><a href="#">Abonnement</a></li>
                  <li class="li-f"><a href="#">Désabonnement</a></li>
                  <li class="li-f"><a href="#">Règles d'utilisation</a></li>
                  <li class="li-f"><a href="#">Support</a></li>
            </div>
            
            <div class="col-xs-12 col-md-3 col-lg-3">
                	<p class="titre-footer">MÉDIAS SOCIAUX</p>
                    <a class="facebookBtn smGlobalBtn" href="http://www.facebook.com" ></a>
                    <a class="twitterBtn smGlobalBtn" href="http://www.twitter.com" ></a>
                    <a class="googleplusBtn smGlobalBtn" href="http://www.plus.google.com" ></a>
                    <a class="linkedinBtn smGlobalBtn" href="http://www.linkedin.com" ></a>
            </div>
            
           <div class="col-xs-12 col-md-3 col-lg-3">
       		<img src="<?= ROOT_URL ?>assets/images/logo.svg" alt="" width="140px"/>
            <li class="li-f"><a href="#">Echange &copy; 2018</li>
            </div>
            
  </div>
     
	</footer>
