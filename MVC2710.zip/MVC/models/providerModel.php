<?php
class ProviderModel extends Model{
  
    /*supprimer prestataire*/
    public function profilProvider($id){
        return array(''=>'');
    }
    

   
}