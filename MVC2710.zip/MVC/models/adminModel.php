<?php
class adminModel extends Model{
    /*valider un prestataire*/
    public function validateFreelancer(){      

    }

    /*supprimer un prestataire*/
    public function deleteFreelancer(){      

    }

    /*valider un contrat*/
    public function validateContract(){      

    }

    /*supprimer un prestataire*/
    public function deleteContract(){      

    }

    /*ajouter un admin*/
    public function addAdmin(){      

    }

    /*modifier un admin*/
    public function updateAdmin(){      

    }

    /*supprimer un admin*/
    public function deleteAdmin(){      

    }
   
}