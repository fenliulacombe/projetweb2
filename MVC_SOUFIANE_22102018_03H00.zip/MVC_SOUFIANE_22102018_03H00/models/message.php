<?php
class messageModel extends Model{

    //  requete Message Recu 
    public function getMessage($id_get){

       $this->query('SELECT *,COUNT(`id_msg`) AS nbrmessage FROM `message` 
                INNER JOIN `utilisateur` ON `utilisateur`.`id_ut` = `message`.`id_destinateur_msg`
                WHERE `id_destinateur_msg` = :id_get ');
            $this->bind(":id_get", $id_get);
            $this->execute();
            $row = resultSet();
    }

    //  requete Message envoyer  
     public function sendMessage($id_send){

       $this->query('SELECT *,COUNT(`id_msg`) AS nbrmessage FROM `message` 
                INNER JOIN `utilisateur` ON `utilisateur`.`id_ut` = `message`.`id_destinateur_msg`
                WHERE `id_expediteur_msg` = :id_post ');
            $this->bind(":id_post", $id_post);
            $this->execute();
            $row = resultSet();
    }


    //  requete envoyer un message 
    public function addMessage($message){

       $this->query('INSERT INTO `pw2`.`message` (`message_msg`, `titre_msg`, `date_msg`, `id_expediteur_msg`, `id_destinateur_msg`, `etat_lu_msg`, `date_lu_msg`) VALUES (:message_msg,:titre_msg,:date_msg,:id_expediteur_msg,:id_destinateur_msg, :etat_lu_msg, :date_lu_msg)');
            $this->bind(':message_msg', $message->message_msg);
            $this->bind(':titre_msg', $message->titre_msg);
            $this->bind(':date_msg', $message->date_msg);
            $this->bind(':id_expediteur_msg', $message->id_expediteur_msg);
            $this->bind(':id_destinateur_msg', $message->id_destinateur_msg);
            $this->bind(':etat_lu_msg', $message->etat_lu_msg);
            $this->bind(':date_lu_msg', $message->date_lu_msg);
            $this->execute();
    }


    // Delete Message

    public function deleteMessage($id){
        $this->query("DELETE * FROM message WHERE id_msg = :id");
        $this->bind(":id", $id);
        $this->execute();
    }
}