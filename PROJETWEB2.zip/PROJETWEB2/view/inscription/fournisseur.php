<!doctype html>
<html lang="en">
<head>
    <?php include '../../view/includes/meta.php'; ?>
    <title>Inscription fournisseur</title>
</head>
<body>  
<div class="container">
    <!--Partie LOGO/MENU--> 
    <?php include '../../view/includes/header.php'; ?>
    <!--Formulaire inscription des prestataires--> 
    <h3>Inscription fournisseur</h3>
    <div class="row">
        <div class="col-sm-4">
        <form>
          <div class="form-group">
            <label for="exampleFormControlInput1">Nom d’utilisateur *</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Courriel professionnel *</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Mot de passe *</label>
            <input type="password" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Confirmer le mot de passe</label>
            <input type="password" class="form-control" id="exampleFormControlInput1">
          </div>
        </div>
        <div class="col-sm-8">
          <div class="form-group">
            <label for="exampleFormControlInput1">Nom *</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Prenom *</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Adresse *</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlSelect1">Ville *</label>
            <select class="form-control" id="exampleFormControlSelect1">
              <option>1</option>
              <option>2</option>
              <option>3</option>
            </select>
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Nom de votre entreprise *</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Numéro de téléphone </label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Numéro d’entreprise du Québec (NEQ)</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">Site web (URL)</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <div class="form-group">
            <label for="exampleFormControlInput1">LinkedIn</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
         <div class="form-group">
            <label for="exampleFormControlInput1">Facebook</label>
            <input type="text" class="form-control" id="exampleFormControlInput1">
          </div>
          <button type="submit" class="btn btn-primary">Soumettre</button>
        </form>
        </div>
    </div>
</div>


</body>
</html>