<!doctype html>
<html lang="en">
<head>
    <?php include '../../view/includes/meta.php'; ?>
    <title>Liste des contrats/projets</title>
</head>
<body>  
<div class="container">
    <!--Partie LOGO/MENU--> 
    <?php include '../../view/includes/header.php'; ?>
    <!--Liste des projets / contrats-->
    <div class="row">
        <div class="col">
            <h3>Liste des contrats (boucle PHP)</h3>
            <p>exemple de contenu</p>  
            <!--Cette partie doit etre dans une boucle pour afficher la liste-->
            <table class="table" style="border: 1px solid;">
            <tbody>
              <tr>
                <th>Titre du contrat (exemple: Programmation formulaire web)</th>
                <th>Date (ex: 09 Octobre 2018)</th>
              </tr>
              <tr>
                <td>Soumissionnaires: (ex: 12)
                  <br>
                  Budget de ...$ à ...$ </td>
                <td>OUVERT ou FERMÉ</td>
              </tr>
            </tbody>
            </table>
            <!--Fin de la boucle-->
        </div>
    </div>
</div>


</body>
</html>