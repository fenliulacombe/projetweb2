<div class="row">
<div class="col-sm-6">
  <p><a href="/PROJETWEB2/">logo</a></p>
</div>
<div class="col-sm-6">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="/PROJETWEB2/view/prestataire/liste_prestataires.php">Voir les pigistes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/PROJETWEB2/view/fournisseur/liste_contrats.php">Voir les contrats</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">S'inscrire</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="/PROJETWEB2/view/inscription/prestataire.php">En tant que prestataire</a>
          <a class="dropdown-item" href="/PROJETWEB2/view/inscription/fournisseur.php">En tant que fournisseur</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/PROJETWEB2/view/login">Login</a>
      </li>
    </ul> 
</div>
</div>