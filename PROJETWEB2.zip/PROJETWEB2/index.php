<!doctype html>
<html lang="en">
<head>
    <?php include 'view/includes/meta.php'; ?>
    <title>Page index</title>
</head>
<body>  
<div class="container">
    <!--Partie LOGO/MENU--> 
    <?php include 'view/includes/header.php'; ?>
    <!--Partie prestataires-->
    <h3>Carroussel des prestataires / categorie</h3>
    <p>exemple de contenu</p> 
    <div class="row">
        <!--Cette partie doit etre dans une boucle pour afficher les blocs-->
        <div class="card" style="width:260px">
          <img class="card-img-top" src="img_avatar1.png" alt="Card image">
          <div class="card-body">
            <h5 class="card-title">Designers/Artistes</h5>
          </div>
        </div>
        <div class="card" style="width:260px">
          <img class="card-img-top" src="img_avatar1.png" alt="Card image">
          <div class="card-body">
            <h5 class="card-title">Programmeurs</h5>
          </div>
        </div>
        <div class="card" style="width:260px">
          <img class="card-img-top" src="img_avatar1.png" alt="Card image">
          <div class="card-body">
            <h5 class="card-title">Redacteurs/Traducteurs</h5>
          </div>
        </div>
        <div class="card" style="width:260px">
          <img class="card-img-top" src="img_avatar1.png" alt="Card image">
          <div class="card-body">
            <h5 class="card-title">Photographes</h5>
          </div>
        </div>
        <!--Fin de la boucle-->
    </div>
    <!--Partie liste des contrats / publier un contrat-->
    <div class="row">
        <div class="col-sm-8">
            <h3>Liste des contrats (boucle PHP)</h3>
            <p>exemple de contenu</p>  
            <!--Cette partie doit etre dans une boucle pour afficher la liste-->
            <table class="table" style="border: 1px solid;">
            <tbody>
              <tr>
                <th>Titre du contrat (exemple: Programmation formulaire web)</th>
                <th>Date (ex: 09 Octobre 2018)</th>
              </tr>
              <tr>
                <td>Soumissionnaires: (ex: 12)
                  <br>
                  Budget de ...$ à ...$ </td>
                <td>OUVERT ou FERMÉ</td>
              </tr>
            </tbody>
            </table>
            <!--Fin de la boucle-->
        </div>
        <div class="col-sm-4">
            <a href="fournisseur/publier.php" class="btn btn-success">Publier un contrat</a>
        </div>
    </div>
</div>


</body>
</html>